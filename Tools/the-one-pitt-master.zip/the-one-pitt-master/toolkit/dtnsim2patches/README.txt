Patches that have to be applied to dtnsim2 sources for dtnsim2parser to work properly.
