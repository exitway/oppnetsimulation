#! /bin/sh
java -Xmx512M -cp /Files/Docs/delay/one_1.4.1/:/Files/Docs/delay/one_1.4.1/lib/ECLA.jar:/Files/Docs/delay/one_1.4.1/lib/DTNConsoleConnection.jar:/Files/Docs/delay/one_1.4.1/lib/uncommons-maths-1.2.1.jar core.DTNSim $*
